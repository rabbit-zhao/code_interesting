# xiuren mzitu
秀人网爬虫 55156爬虫 mzitu

使用Python3.6的版本 

# 安装

```
pip install scrapy
```
如果遇到有些模块在windos装不上，到[这个网站](http://www.lfd.uci.edu/~gohlke/pythonlibs/)下载相应的模块，然后用pip安装。

# 运行
```
python run.py
```

默认是爬取的55156 还可以在run.py里面去掉注释爬取mzitu

# 结果
![noproxy.gif](http://upload-images.jianshu.io/upload_images/2189945-55d51000ca75c96a.gif?imageMogr2/auto-orient/strip)

![目录.png](http://upload-images.jianshu.io/upload_images/2189945-00f8ba822e11adfb.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)

![结果.png](http://upload-images.jianshu.io/upload_images/2189945-b8e824b837a505cc.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)